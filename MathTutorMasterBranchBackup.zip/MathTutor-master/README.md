# MathTutor
Math tutor project


Here are the two diagrams I have so far. We should plan on finalizing these two and adding the Problem statement in class 11/28.
I am sure we can get the rest of this knocked out in class and get started on building all the necessary components for the 
program in the next week or two. 
