package problem;

import java.util.Random;

public class DivisionProblem extends Problem

{

	
	public DivisionProblem() 
	
	{
		question = a + " ÷ " + b + " = ";
	}
	
	public String getQuestion()
	{
		return question;
	}

	@Override
	int getAnswer()
	{
		// TODO Auto-generated method stub
		return 0;
	}
	
	
}