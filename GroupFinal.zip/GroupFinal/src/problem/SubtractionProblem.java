package problem;

import java.util.Random;

public class SubtractionProblem extends Problem

{
	
	
	
	public SubtractionProblem() 
	
	{
		question = a + " - " + b + " = ";
	}
	public String getQuestion()
	{
		return question;
	}
	@Override
	int getAnswer()
	{
		// TODO Auto-generated method stub
		return 0;
	}
	
	
}