package problem;

import java.util.Random;

public class MultiplicationProblem extends Problem

{

	public MultiplicationProblem() 
	
	{
		question = a + " x " + b + " = ";
	}
	public String getQuestion()
	{
		return question;
	}
	@Override
	int getAnswer()
	{
		// TODO Auto-generated method stub
		return 0;
	}
	
	
}