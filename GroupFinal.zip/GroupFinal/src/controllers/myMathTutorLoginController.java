package controllers;

import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import primary.SerializableApp;
import primary.User;

public class myMathTutorLoginController
{
	public static User currentUser;
	@FXML
	private TextField userTxtField;

	@FXML
	private TextField passTxtField;

	@FXML
	private Button loginBtn;

	@FXML
	private Button signUpBtn;
	
	@FXML
    private Label notFoundLabel;

	@FXML
	void login(ActionEvent event)
	{
		User user = null;
		boolean checkUser = false;
		boolean checkPass = false;
		
		if(userTxtField.getText().equals("Admin") && passTxtField.getText().equals("Admin"))
		{
			launchAdminScreen();
			return;
		}
		checkUser = checkUsername(userTxtField.getText());
		
		if (checkUser == false)
		{
			notFoundLabel.setVisible(true);
			return;
		}
		if (checkUser == true)
		{
			user = findUser(userTxtField.getText());
			checkPass = checkPassword(user, passTxtField.getText());
		}
		if (checkPass == false)
		{
			notFoundLabel.setVisible(true);
			return;
		}
		if (checkPass == true & checkUser == true)
		{
			currentUser = user;
			
		}
		
		loginBtn.getScene().getWindow().hide();
		launchMyAccountScreen();
		
	}

	@FXML
	void signUp(ActionEvent event)
	{
		userTxtField.getScene().getWindow().hide();
		launchCreateAccountScreen();
	}
	
	@FXML
    void passwordPressed(KeyEvent event) {
		notFoundLabel.setVisible(false);
    }
	
	  @FXML
	    void usernamePressed(KeyEvent event) {
		  notFoundLabel.setVisible(false);
	    }

	private void launchAdminScreen()
	{
		try
		{
			Parent createAccount = FXMLLoader.load(getClass().getResource("/fxml/myMathAdmin.fxml"));

			Scene scene = new Scene(createAccount);
			Stage stage = new Stage();
			stage.setTitle("Admin");
			stage.setScene(scene);
			stage.show();
		} catch (Exception e)
		{
			System.out.println("Can't open About window.");
		}
	}

	private void launchCreateAccountScreen()
	{
		try
		{
			Parent createAccount = FXMLLoader.load(getClass().getResource("/fxml/myMathTutorCreateAccount.fxml"));

			Scene scene = new Scene(createAccount);
			Stage stage = new Stage();
			stage.setTitle("Create Account");
			stage.setScene(scene);
			stage.show();
		} catch (Exception e)
		{
			System.out.println("Can't open About window.");
		}
	}
	private void launchMyAccountScreen()
	{
		try
		{
			Parent myAccount = FXMLLoader.load(getClass().getResource("/fxml/myMathTutorWelcome.fxml"));

			Scene scene = new Scene(myAccount);
			Stage stage = new Stage();
			stage.setTitle("My Account");
			stage.setScene(scene);
			stage.show();
		} catch (Exception e)
		{
			System.out.println("Can't open About window.");
		}
	}
	private static boolean checkUsername(String inputUsername)
	{
		boolean check = false;
		ArrayList<User> myList = new ArrayList<User>();
		myList = SerializableApp.deserialize("users.ser");

		for (User u : myList)

		{
			if (u.getUserName().equals(inputUsername))
				check = true;
		}
		return check;
	}
	private static boolean checkPassword(User user, String password)
	{
		boolean check = false;

		if (user.getPassword().equals(password))
			check = true;

		return check;

	}
	private static User findUser(String userName)
	{
		ArrayList<User> myList = new ArrayList<User>();
		myList = SerializableApp.deserialize("users.ser");

		User myUser = null;

		for (User u : myList)
		{
			if (u.getUserName().equals(userName))
				myUser = u;
		}

		return myUser;
	}
	public static User getUser()
	{
		return currentUser;
	}
	
}


