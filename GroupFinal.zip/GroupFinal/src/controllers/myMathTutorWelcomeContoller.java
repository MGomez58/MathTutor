package controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class myMathTutorWelcomeContoller
{

    @FXML
    private Button lastActionBtn;

    @FXML
    private Text overallTxtLabel;

    @FXML
    private Text rtwTxtLabel;

    @FXML
    private Text lessonCompTxtLabel;

    @FXML
    private Text qAnsTxtLabel;

    @FXML
    private Button logoutBtn;

    @FXML
    void continueLastAction(ActionEvent event) {
    	//continues last action of the session
    }

    @FXML
    void logOut(ActionEvent event) {
    	logoutBtn.getScene().getWindow().hide();
		try
		{
			Parent myAccount = FXMLLoader.load(getClass().getResource("/fxml/myMathTutorLogin.fxml"));

			Scene scene = new Scene(myAccount);
			Stage stage = new Stage();
			stage.setTitle("Math Tutor");
			stage.setScene(scene);
			stage.show();
		} catch (Exception e)
		{
			System.out.println("Can't open About window.");
		}

    }

	
	

}
