package controllers;

import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import primary.SerializableApp;
import primary.User;

public class myMathTutorAdminController {
	
	ArrayList<User> list = new ArrayList<User>();
	ObservableList<User> options = FXCollections.observableArrayList();

    @FXML
    private TextField userTxtField;

    @FXML
    private TextField passwordTxtField;

    @FXML
    private TextField lessonsCompTxtField;

    @FXML
    private TextField avgScoreTextField;

    @FXML
    private ComboBox<User> comboBox;

    @FXML
    void addUser(ActionEvent event) {
    	list = SerializableApp.deserialize("users.ser");
		User newUser = new User(userTxtField.getText(), passwordTxtField.getText());
		list.add(newUser);
		options.add(newUser);
		comboBox.setItems(options);
		SerializableApp.serialize(list, "users.ser");

    }

    @FXML
    void comboBoxAction(ActionEvent event) {

    }

    @FXML
    void removeUser(ActionEvent event) {
    	User delete = comboBox.getValue();
		System.out.println(delete);
		options.remove(delete);
		list.remove(delete);
		SerializableApp.serialize(list, "users.ser");
		comboBox.setValue(null);
    }

    @FXML
    void updateUser(ActionEvent event) {

    }
    
	@FXML
	void initialize()
	{

		list = SerializableApp.deserialize("users.ser");
		for (User user : list)
		{
			options.add(user);
		}
		comboBox.setItems(options);

	}

}
