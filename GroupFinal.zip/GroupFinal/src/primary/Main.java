package primary;

import java.io.File;
import java.util.ArrayList;


import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.stage.Stage;

public class Main extends Application
{
	
	@Override
	public void start(Stage stage)
	{
		try
		{
			Parent root = FXMLLoader.load(getClass().getResource("/fxml/myMathTutorLogin.fxml")); 
			Scene scene = new Scene(root); // attach scene graph to scene
			stage.setTitle("Math Tutor"); // displayed in window's title bar
			stage.setScene(scene); // attach scene to stage
			stage.show(); // display the stage

		} catch (Exception e)
		{
			e.printStackTrace();
		}
		if(!new File("users.ser").isFile())
		{
			User admin = new User("Admin", "Admin");
			ArrayList<User> myList = new ArrayList<User>();
			myList.add(admin);
			SerializableApp.serialize(myList, "users.ser");	
		}
	}

	public static void main(String[] args)
	{
		launch(args);
		
		
	}
	
	  @Override
	    public void stop() 
	  {
	       
	       
	       
	       
	       
	  }


	  
}