package myMathTutor;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class signUpController {

    @FXML
    private TextField userNameTxtField;

    @FXML
    private TextField confirmTxtField;

    @FXML
    private TextField passwordTxtField;

    @FXML
    private Button cancelBtn;

    @FXML
    private Button signUpBtn;

    @FXML
    void clearForm(ActionEvent event) {

    }

    @FXML
    void signUp(ActionEvent event) {

    }

}

