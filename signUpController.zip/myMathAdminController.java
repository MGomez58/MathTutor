package myMathTutor;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class myMathAdminController {

    @FXML
    private TextField userTxtField;

    @FXML
    private TextField passwordTxtField;

    @FXML
    private TextField lessonsCompTxtField;

    @FXML
    private TextField avgScoreTextField;

    @FXML
    void addUser(ActionEvent event) {

    }

    @FXML
    void removeUser(ActionEvent event) {

    }

    @FXML
    void updateUser(ActionEvent event) {

    }

}

