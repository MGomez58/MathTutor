package myMathTutor;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class myMathTutorLoginController implements GetAccount{

    @FXML
    private TextField userTxtField;

    @FXML
    private TextField passTxtField;

    @FXML
    private Button loginBtn;

    @FXML
    void login(ActionEvent event) {
    	//checks both txtFields to see of they are viable entries
    	//if not an exception will occur displaying an alert

    }

	@Override
	public void getAccount() {
		// TODO Auto-generated method stub

	}

}

