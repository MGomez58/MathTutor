package myMathTutor;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;

public class myMathTutorProblemController implements GetAccount{

	@FXML
    private Text problemLbl;

    @FXML
    private TextField ansTxtField;

    @FXML
    private Button subBtn;

    @FXML
    private Button hintBtn;

    @FXML
    private Button nextBtn;

    @FXML
    private Button prevBtn;

    @FXML
    private ImageView imgView;

    @FXML
    private Text feedbackTxtLabel;

    @FXML
    private ComboBox<?> questionCB;

    @FXML
    void checkAnswer(ActionEvent event) {
    	//retrieve answer from text field
    	//check to see if solution matches the predetermined answer
    	//display feedback
    	//increments stats

    }

    @FXML
    void displayHint(ActionEvent event) {
    	//pulls up another gui for hints depending on the problems enum

    }

    @FXML
    void nextQ(ActionEvent event) {
    	//increments to next question

    }

    @FXML
    void previousQ(ActionEvent event) {
    	//decrements to previous question

    }

    @FXML
    void setQuestion(ActionEvent event) {
    	//displays question depending on selection of the combo box

    }

	@Override
	public void getAccount() {
		// TODO Auto-generated method stub

	}

}

