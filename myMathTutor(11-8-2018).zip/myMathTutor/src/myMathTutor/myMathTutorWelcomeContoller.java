package myMathTutor;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.text.Text;

public class myMathTutorWelcomeContoller implements GetAccount{

    @FXML
    private Button lastActionBtn;

    @FXML
    private Text overallTxtLabel;

    @FXML
    private Text rtwTxtLabel;

    @FXML
    private Text lessonCompTxtLabel;

    @FXML
    private Text qAnsTxtLabel;

    @FXML
    private Button logoutBtn;

    @FXML
    void continueLastAction(ActionEvent event) {
    	//continues last action of the session
    }

    @FXML
    void logOut(ActionEvent event) {
    //logs current user out of thier session

    }

	@Override
	public void getAccount() {
		// TODO Auto-generated method stub

	}

}
