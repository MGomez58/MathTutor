package myMathTutor;

public interface GetAccount {

	public void getAccount();


}
